import React from 'react';
import { useNavigate } from 'react-router-dom';
import './AdminSidebar.css';

const AdminSidebar = ({ isOpen, onClose }) => {
    const navigate = useNavigate();

    const handleNavigation = (path) => {
        navigate(path);
        onClose();
    };

    return (
        <div className={`admin-sidebar ${isOpen ? 'open' : ''}`}>
            <div className="sidebar-header">
                <h2>Admin Panel</h2>
            </div>
            <nav className="sidebar-nav">
                <button 
                    className="nav-link"
                    onClick={() => handleNavigation('/admin/dashboard')}
                >
                    Dashboard
                </button>
                <button 
                    className="nav-link"
                    onClick={() => handleNavigation('/admin/upcoming-events')}
                >
                    Upcoming Events
                </button>
                <button 
                    className="nav-link"
                    onClick={() => handleNavigation('/admin/completed-events')}
                >
                    Completed Events
                </button>
                <button 
                    className="nav-link"
                    onClick={() => handleNavigation('/admin/user-management')}
                >
                    User Management
                </button>
                <button 
                    className="nav-link"
                    onClick={() => handleNavigation('/admin/settings')}
                >
                    Settings
                </button>
                <button 
                    className="nav-link logout"
                    onClick={() => handleNavigation('/admin-login')}
                >
                    Logout
                </button>
            </nav>
        </div>
    );
};

export default AdminSidebar; 