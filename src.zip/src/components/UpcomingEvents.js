import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainSidebar from './MainSidebar';
import './UpcomingEvents.css';

function UpcomingEvents() {
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Mock data for upcoming events
  const upcomingEvents = [
    {
      id: 1,
      title: "Web Development Workshop",
      date: "2025-03-28",
      time: "10:00 AM",
      venue: "Room 101",
      type: "Workshop",
      participants: 25,
      activityPoints: 5,
      registrationFee: "₹100",
      status: "Open"
    },
    {
      id: 2,
      title: "Database Management Seminar",
      date: "2025-03-28",
      time: "2:00 PM",
      venue: "Auditorium",
      type: "Seminar",
      participants: 50,
      activityPoints: 3,
      registrationFee: "₹50",
      status: "Open"
    },
    {
      id: 3,
      title: "Machine Learning Workshop",
      date: "2025-03-27",
      time: "11:00 AM",
      venue: "Lab 205",
      type: "Workshop",
      participants: 30,
      activityPoints: 5,
      registrationFee: "₹150",
      status: "Open"
    },
    {
      id: 4,
      title: "Cloud Computing Seminar",
      date: "2025-03-31",
      time: "3:00 PM",
      venue: "Conference Hall",
      type: "Seminar",
      participants: 40,
      activityPoints: 3,
      registrationFee: "₹75",
      status: "Open"
    }
  ];

  return (
    <div className="upcoming-events-container">
      <MainSidebar 
        isOpen={isSidebarOpen} 
        onClose={toggleSidebar}
      />
      
      <div className={`main-content ${isSidebarOpen ? 'shifted' : ''}`}>
        <header className="header">
          <button className="menu-button" onClick={toggleSidebar}>
            ☰
          </button>
          <h1>Upcoming Events</h1>
        </header>

        <main className="events-grid">
          {upcomingEvents.map(event => (
            <div key={event.id} className="event-card">
              <h3>{event.title}</h3>
              <div className="event-details">
                <div className="details-row">
                  <p><strong>Date:</strong> {event.date}</p>
                  <p><strong>Time:</strong> {event.time}</p>
                </div>
                <div className="details-row">
                  <p><strong>Venue:</strong> {event.venue}</p>
                  <p><strong>Type:</strong> {event.type}</p>
                </div>
                <div className="details-row">
                  <p><strong>Participants:</strong> {event.participants}</p>
                  <p><strong>Activity Points:</strong> {event.activityPoints}</p>
                </div>
                <div className="details-row">
                  <p><strong>Registration Fee:</strong> {event.registrationFee}</p>
                  <p><strong>Status:</strong> {event.status}</p>
                </div>
              </div>
              {/* <a href={`/upcoming-events/${event.id}`} className="register-button">
                Register Now
              </a> */}
              <a href="https://docs.google.com/forms/u/0/d/19GAG4YFRzoiA5evgjjcPbAomkIsGHj0KiA4qnw4g7Pw/edit" className="register-button">
                Register Now
              </a>
            </div>
          ))}
        </main>
      </div>

      {isSidebarOpen && (
        <div className="overlay" onClick={toggleSidebar}></div>
      )}
    </div>
  );
}

export default UpcomingEvents; 