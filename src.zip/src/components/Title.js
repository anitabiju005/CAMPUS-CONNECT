import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Title.css';

const Title = () => {
    const navigate = useNavigate();

    const handleClick = () => {
        navigate('/login');
    };

    return (
        <div className="title-container" onClick={handleClick}>
            <div className="title-content">
                <div className="title-text">
                    <div className="campus-text">CAMPUS</div>
                    <div className="connect-text">
                        CONNE<span className="circle-c">C</span>T
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Title; 