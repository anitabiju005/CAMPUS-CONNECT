import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainSidebar from './MainSidebar';
import './Settings.css';

const Settings = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(false);
    const navigate = useNavigate();
    const [theme, setTheme] = useState('light');
    const [notifications, setNotifications] = useState({
        email: true,
        push: true,
        sms: false
    });

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    const handleThemeChange = (newTheme) => {
        setTheme(newTheme);
        // Here you would typically update the theme in your app's state management
        document.body.setAttribute('data-theme', newTheme);
    };

    const handleNotificationToggle = (type) => {
        setNotifications(prev => ({
            ...prev,
            [type]: !prev[type]
        }));
    };

    return (
        <div className={`settings-container ${isSidebarOpen ? 'sidebar-open' : ''}`}>
            {/* Header */}
            <header className="header">
                <button className="menu-button" onClick={toggleSidebar}>☰</button>
                <h1>Campus Connect</h1>
            </header>

            {/* Main Sidebar */}
            <MainSidebar isOpen={isSidebarOpen} onClose={toggleSidebar} />

            {/* Main Content */}
            <main className="main-content">
                <div className="content-wrapper">
                    <h2 className="settings-title">Settings</h2>
                    
                    <div className="settings-grid">
                        {/* Theme Settings */}
                        <div className="settings-section">
                            <h3>Theme Settings</h3>
                            <div className="theme-options">
                                <div className="theme-option">
                                    <div className={`theme-preview light ${theme === 'light' ? 'active' : ''}`}>
                                        <div className="theme-circle"></div>
                                    </div>
                                    <label>Light Theme</label>
                                    <input
                                        type="radio"
                                        name="theme"
                                        value="light"
                                        checked={theme === 'light'}
                                        onChange={() => handleThemeChange('light')}
                                    />
                                </div>
                                <div className="theme-option">
                                    <div className={`theme-preview dark ${theme === 'dark' ? 'active' : ''}`}>
                                        <div className="theme-circle"></div>
                                    </div>
                                    <label>Dark Theme</label>
                                    <input
                                        type="radio"
                                        name="theme"
                                        value="dark"
                                        checked={theme === 'dark'}
                                        onChange={() => handleThemeChange('dark')}
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Notification Settings */}
                        <div className="settings-section">
                            <h3>Notification Preferences</h3>
                            <div className="notification-settings">
                                <div className="notification-option">
                                    <label>Email Notifications</label>
                                    <div className="toggle-switch">
                                        <input
                                            type="checkbox"
                                            checked={notifications.email}
                                            onChange={() => handleNotificationToggle('email')}
                                        />
                                        <span className="toggle-slider"></span>
                                    </div>
                                </div>
                                <div className="notification-option">
                                    <label>Push Notifications</label>
                                    <div className="toggle-switch">
                                        <input
                                            type="checkbox"
                                            checked={notifications.push}
                                            onChange={() => handleNotificationToggle('push')}
                                        />
                                        <span className="toggle-slider"></span>
                                    </div>
                                </div>
                                <div className="notification-option">
                                    <label>SMS Notifications</label>
                                    <div className="toggle-switch">
                                        <input
                                            type="checkbox"
                                            checked={notifications.sms}
                                            onChange={() => handleNotificationToggle('sms')}
                                        />
                                        <span className="toggle-slider"></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Privacy Settings */}
                        <div className="settings-section">
                            <h3>Privacy Settings</h3>
                            <div className="privacy-settings">
                                <div className="privacy-option">
                                    <label>Profile Visibility</label>
                                    <select className="settings-select">
                                        <option value="public">Public</option>
                                        <option value="friends">Friends Only</option>
                                        <option value="private">Private</option>
                                    </select>
                                </div>
                                <div className="privacy-option">
                                    <label>Activity Feed</label>
                                    <select className="settings-select">
                                        <option value="all">Show All</option>
                                        <option value="friends">Friends Only</option>
                                        <option value="none">Hide</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        {/* Language Settings */}
                        <div className="settings-section">
                            <h3>Language Settings</h3>
                            <div className="language-settings">
                                <select className="settings-select">
                                    <option value="en">English</option>
                                    <option value="es">Spanish</option>
                                    <option value="fr">French</option>
                                    <option value="de">German</option>
                                    <option value="hi">Hindi</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div className="settings-actions">
                        <button className="save-button">Save Changes</button>
                        <button className="reset-button">Reset to Default</button>
                    </div>
                </div>
            </main>

            {/* Footer */}
            <footer className="footer">
                <p>&copy; 2024 Campus Connect. All rights reserved.</p>
            </footer>

            {/* Overlay */}
            {isSidebarOpen && (
                <div className="overlay" onClick={toggleSidebar}></div>
            )}
        </div>
    );
};

export default Settings; 