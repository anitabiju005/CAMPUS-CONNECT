import React from 'react';
import { useNavigate } from 'react-router-dom';
import './MainSidebar.css';

function MainSidebar({ isOpen, onClose }) {
    const navigate = useNavigate();

    const handleNavigation = (path) => {
        if (path === '/administrator') {
            navigate('/admin/login');
        } else {
            navigate(path);
        }
        onClose();
    };

    return (
        <div className={`main-sidebar ${isOpen ? 'open' : ''}`}>
            <div className="sidebar-header">
                <h2>Campus Connect</h2>
            </div>
            <nav className="sidebar-nav">
                <button onClick={() => handleNavigation('/home')} className="nav-link">
                    Dashboard
                </button>
                <button onClick={() => handleNavigation('/profile')} className="nav-link">
                    Profile
                </button>
                <button onClick={() => handleNavigation('/upcoming-events')} className="nav-link">
                    Upcoming Events
                </button>
                <button onClick={() => handleNavigation('/registered-events')} className="nav-link">
                    Registered Events
                </button>
                <button onClick={() => handleNavigation('/administrator')} className="nav-link">
                    Administrator
                </button>
                <button onClick={() => handleNavigation('/settings')} className="nav-link">
                    Settings
                </button>
                <button onClick={() => handleNavigation('/help')} className="nav-link">
                    Help
                </button>
            </nav>
        </div>
    );
}

export default MainSidebar; 