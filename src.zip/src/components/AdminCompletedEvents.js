import React, { useState } from 'react';
import './AdminCompletedEvents.css';

const AdminCompletedEvents = () => {
    // Mock data for completed events
    const [completedEvents] = useState([
        {
            id: 1,
            title: "Web Development Bootcamp",
            type: "Workshop",
            date: "2024-02-15",
            time: "10:00 AM - 1:00 PM",
            venue: "Room 301, Computer Science Building",
            participants: 75,
            activityPoints: 50,
            registrationFee: "₹500",
            status: "Completed",
            report: "The workshop was well-received with high participant engagement. All attendees successfully completed the hands-on exercises."
        },
        {
            id: 2,
            title: "AI Competition 2024",
            type: "Competition",
            date: "2024-02-20",
            time: "9:00 AM - 6:00 PM",
            venue: "Innovation Hub, Main Campus",
            participants: 150,
            activityPoints: 100,
            registrationFee: "₹1000",
            status: "Completed",
            winners: {
                first: "Team Alpha - John Doe & Jane Smith",
                second: "Team Beta - Mike Johnson & Sarah Wilson",
                third: "Team Gamma - Alex Brown & Emma Davis"
            }
        },
        {
            id: 3,
            title: "Networking Event",
            type: "General",
            date: "2024-02-25",
            time: "11:00 AM - 4:00 PM",
            venue: "University Auditorium",
            participants: 100,
            activityPoints: 75,
            registrationFee: "Free",
            status: "Completed",
            report: "Successful networking event with industry professionals. Students had valuable interactions with potential employers."
        }
    ]);

    return (
        <div className="admin-completed-events">
            <div className="admin-events-header">
                <h1>Completed Events</h1>
            </div>
            
            <div className="admin-events-grid">
                {completedEvents.map(event => (
                    <div key={event.id} className="admin-event-card">
                        <div className="admin-event-header">
                            <h2>{event.title}</h2>
                            <span className={`event-type ${event.type.toLowerCase()}`}>
                                {event.type}
                            </span>
                        </div>
                        
                        <div className="admin-event-details">
                            <div className="detail-item">
                                <span className="detail-label">Date:</span>
                                <span className="detail-value">{event.date}</span>
                            </div>
                            <div className="detail-item">
                                <span className="detail-label">Time:</span>
                                <span className="detail-value">{event.time}</span>
                            </div>
                            <div className="detail-item">
                                <span className="detail-label">Venue:</span>
                                <span className="detail-value">{event.venue}</span>
                            </div>
                            <div className="detail-item">
                                <span className="detail-label">Participants:</span>
                                <span className="detail-value">{event.participants}</span>
                            </div>
                            <div className="detail-item">
                                <span className="detail-label">Activity Points:</span>
                                <span className="detail-value">{event.activityPoints}</span>
                            </div>
                            <div className="detail-item">
                                <span className="detail-label">Registration Fee:</span>
                                <span className={`detail-value ${event.registrationFee === 'Free' ? 'free' : 'fee'}`}>
                                    {event.registrationFee}
                                </span>
                            </div>
                            <div className="detail-item">
                                <span className="detail-label">Status:</span>
                                <span className={`detail-value status ${event.status.toLowerCase()}`}>
                                    {event.status}
                                </span>
                            </div>
                        </div>

                        {event.type === "Competition" ? (
                            <div className="winners-section">
                                <h3>Winners</h3>
                                <ul className="winners-list">
                                    <li className="winner-item first">
                                        <i className="fas fa-medal"></i> 1st Place: {event.winners.first}
                                    </li>
                                    <li className="winner-item second">
                                        <i className="fas fa-medal"></i> 2nd Place: {event.winners.second}
                                    </li>
                                    <li className="winner-item third">
                                        <i className="fas fa-medal"></i> 3rd Place: {event.winners.third}
                                    </li>
                                </ul>
                            </div>
                        ) : (
                            <div className="report-section">
                                <h3>Event Report</h3>
                                <p className="report-text">{event.report}</p>
                            </div>
                        )}

                        <div className="admin-event-actions">
                            <button className="edit-btn">
                                <i className="fas fa-pencil-alt"></i> Edit
                            </button>
                            <button className="delete-btn">Delete</button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AdminCompletedEvents; 