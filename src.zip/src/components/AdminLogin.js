import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './AdminLogin.css';

const AdminLogin = () => {
    const [adminPassword, setAdminPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        try {
            const response = await fetch('http://localhost:5000/api/admin/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ adminPassword }),
            });

            const data = await response.json();

            if (response.ok) {
                // Store login state
                localStorage.setItem('isAdmin', 'true');
                navigate('/admin-upcoming-events'); // Redirect after successful login
            } else {
                setError(data.error || 'Admin login failed');
            }
        } catch (err) {
            setError('Server error. Please try again.');
        }
    };

    return (
        <div className="login-container">
            <div className="login-box">
                <div className="login-header">
                    <h1>Administrator Login</h1>
                    <p>Enter administrator password to continue</p>
                </div>

                <form onSubmit={handleSubmit} className="login-form">
                    {error && <div className="error-message">{error}</div>}

                    <div className="form-group">
                        <input
                            type="password"
                            placeholder="Enter Administrator Password"
                            value={adminPassword}
                            onChange={(e) => setAdminPassword(e.target.value)}
                            required
                        />
                    </div>

                    <button type="submit" className="login-button">
                        Login
                    </button>

                    <button 
                        type="button" 
                        className="back-button"
                        onClick={() => navigate(-1)}
                    >
                        Back to Dashboard
                    </button>
                </form>
            </div>
        </div>
    );
};

export default AdminLogin;
