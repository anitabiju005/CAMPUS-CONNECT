import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import MainSidebar from './MainSidebar';
import './Home.css';

const Home = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(false);
    const [selectedDate, setSelectedDate] = useState(new Date());
    const navigate = useNavigate();
    
    // Static statistics data
    const [stats] = useState({
        upcoming: 8,
        ongoing: 3,
        registered: 5,
        completed: 12,
        credits: 45
    });

    // Static events data
    const [events] = useState({
        '2024-03-15': [
            { title: 'Technical Workshop', time: '10:00 AM', type: 'workshop' },
            { title: 'Coding Competition', time: '2:00 PM', type: 'competition' }
        ],
        '2024-03-18': [
            { title: 'AI Seminar', time: '11:00 AM', type: 'seminar' }
        ],
        '2024-03-20': [
            { title: 'Career Fair', time: '9:00 AM', type: 'fair' },
            { title: 'Resume Workshop', time: '2:00 PM', type: 'workshop' }
        ]
    });

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    const handleLogout = () => {
        navigate('/');
    };

    const handleDateClick = (date) => {
        setSelectedDate(date);
    };

    const getEventsForDate = (date) => {
        const dateStr = date.toISOString().split('T')[0];
        return events[dateStr] || [];
    };

    const handleNavigation = (path) => {
        if (path === '/administrator') {
            navigate('/admin-login'); // Navigate to admin login instead of direct admin page
        } else {
            navigate(path);
        }
        setSidebarOpen(false);
    };

    return (
        <div className={`home ${isSidebarOpen ? 'sidebar-open' : ''}`}>
            {/* Header */}
            <header className="home-header">
                <div className="header-left">
                    <button className="menu-button" onClick={toggleSidebar}>☰</button>
                    <h1>Campus Connect</h1>
                </div>
                <button className="logout-button" onClick={handleLogout}>
                    Logout
                </button>
            </header>

            {/* Main Sidebar */}
            <MainSidebar isOpen={isSidebarOpen} onClose={toggleSidebar} />

            {/* Main Content */}
            <main className="home-main-content">
                {/* Welcome Message */}
                <div className="dashboard-header">
                    <h1 className="welcome-message">Welcome to Campus</h1>
                    <p className="dashboard-subtitle">Dashboard</p>
                </div>

                {/* Event Statistics Cards */}
                <div className="stats-container">
                    <div className="stat-card upcoming-events">
                        <div className="stat-icon">📅</div>
                        <div className="stat-content">
                            <h3>Upcoming Events</h3>
                            <p className="stat-number">{stats.upcoming}</p>
                        </div>
                    </div>
                    <div className="stat-card ongoing-events">
                        <div className="stat-icon">🎯</div>
                        <div className="stat-content">
                            <h3>Ongoing Events</h3>
                            <p className="stat-number">{stats.ongoing}</p>
                        </div>
                    </div>
                    <div className="stat-card registered-events">
                        <div className="stat-icon">📝</div>
                        <div className="stat-content">
                            <h3>Registered Events</h3>
                            <p className="stat-number">{stats.registered}</p>
                        </div>
                    </div>
                    <div className="stat-card completed-events">
                        <div className="stat-icon">✅</div>
                        <div className="stat-content">
                            <h3>Completed Events</h3>
                            <p className="stat-number">{stats.completed}</p>
                        </div>
                    </div>
                </div>

                {/* Calendar Section */}
                <div className="calendar-section">
                    <div className="calendar-events-container">
                        <div className="calendar-container">
                            <Calendar
                                onChange={handleDateClick}
                                value={selectedDate}
                                className="custom-calendar"
                                tileClassName={({ date }) => {
                                    const hasEvents = getEventsForDate(date).length > 0;
                                    return hasEvents ? 'has-events' : '';
                                }}
                            />
                        </div>
                        <div className="events-display">
                            <h3>Events for {selectedDate.toLocaleDateString()}</h3>
                            <div className="events-list">
                                {getEventsForDate(selectedDate).length > 0 ? (
                                    getEventsForDate(selectedDate).map((event, index) => (
                                        <div key={index} className="event-item">
                                            <span className="event-time">{event.time}</span>
                                            <span className="event-title">{event.title}</span>
                                            <span className="event-type">{event.type}</span>
                                        </div>
                                    ))
                                ) : (
                                    <p className="no-events">No events scheduled for this date</p>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            {/* Overlay */}
            {isSidebarOpen && (
                <div className="overlay" onClick={toggleSidebar}></div>
            )}
        </div>
    );
};

export default Home; 