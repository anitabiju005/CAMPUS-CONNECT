import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainSidebar from './MainSidebar';
import './Profile.css';

const Profile = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    const navigate = useNavigate();
    const [profileData, setProfileData] = useState({
        name: 'John Doe',
        email: 'john.doe@example.com',
        department: 'Computer Science',
        year: '3rd Year',
        studentId: '2021001',
        phone: '+1 234 567 8900',
        bio: 'Passionate about technology and innovation. Active participant in campus events and workshops.',
        interests: ['Web Development', 'AI', 'Data Science', 'UI/UX Design'],
        achievements: [
            'First Place in Hackathon 2023',
            'Best Project Award in Web Development',
            'Active Participation in 10+ Events'
        ],
        stats: {
            totalEvents: 150,
            completedEvents: 18,
            upcomingEvents: 4,
            activityPoints: 200
        },
        recentActivity: [
            {
                type: 'event',
                title: 'Completed Technical Workshop',
                description: 'Earned 50 activity points',
                date: '2 days ago',
                icon: '🎓'
            },
            {
                type: 'registration',
                title: 'Registered for Hackathon',
                description: 'Upcoming event',
                date: '5 days ago',
                icon: '📝'
            },
            {
                type: 'achievement',
                title: 'Won Coding Competition',
                description: 'Earned 100 activity points',
                date: '1 week ago',
                icon: '🏆'
            }
        ]
    });

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    const handleEdit = () => {
        setIsEditing(true);
    };

    const handleSave = () => {
        setIsEditing(false);
        // Here you would typically save the changes to your backend
    };

    const handleCancel = () => {
        setIsEditing(false);
        // Reset form data to original values if needed
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setProfileData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    return (
        <div className={`profile-container ${isSidebarOpen ? 'sidebar-open' : ''}`}>
            {/* Header */}
            <header className="header">
                <button className="menu-button" onClick={toggleSidebar}>☰</button>
                <h1>Campus Connect</h1>
            </header>

            {/* Main Sidebar */}
            <MainSidebar isOpen={isSidebarOpen} onClose={toggleSidebar} />

            {/* Main Content */}
            <main className="main-content">
                <div className="content-wrapper">
                    {/* Profile Header */}
                    <div className="profile-header">
                        <div className="profile-avatar">
                            <img src="https://i.pravatar.cc/150?img=12" alt="Profile" />
                            {isEditing && (
                                <button className="change-photo-btn">Change Photo</button>
                            )}
                        </div>
                        <div className="profile-info">
                            <h2>{profileData.name}</h2>
                            <p className="student-id">Student ID: {profileData.studentId}</p>
                            <p className="department">{profileData.department} • {profileData.year}</p>
                        </div>
                        {!isEditing && (
                            <button className="edit-profile-btn" onClick={handleEdit}>
                                Edit Profile
                            </button>
                        )}
                    </div>

                    {/* Activity Statistics */}
                    <div className="stats-grid">
                        <div className="stat-card">
                            <div className="stat-icon">📅</div>
                            <div className="stat-content">
                                <h3>Total Events</h3>
                                <p className="stat-value">{profileData.stats.totalEvents}</p>
                                <div className="event-info">
                                    <span>Next Event in 2 days</span>
                                </div>
                                <div className="event-status">
                                    <span className="status-dot"></span>
                                    <span className="status-text">Active</span>
                                </div>
                            </div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-icon">✅</div>
                            <div className="stat-content">
                                <h3>Completed</h3>
                                <p className="stat-value">{profileData.stats.completedEvents}</p>
                                <div className="event-date">Last: 23 Mar 2024</div>
                            </div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-icon">🎯</div>
                            <div className="stat-content">
                                <h3>Upcoming</h3>
                                <p className="stat-value">{profileData.stats.upcomingEvents}</p>
                                <div className="event-info">
                                    <span>Technical Workshop</span>
                                </div>
                            </div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-icon">⭐</div>
                            <div className="stat-content">
                                <h3>Activity Points</h3>
                                <p className="stat-value">{profileData.stats.activityPoints}</p>
                                <div className="event-status">
                                    <span className="status-dot"></span>
                                    <span className="status-text">Level 3</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="profile-grid">
                        {/* Left Column */}
                        <div className="profile-left-column">
                            {/* Personal Information */}
                            <div className="profile-section">
                                <h3>Personal Information</h3>
                                <div className="info-grid">
                                    <div className="info-item">
                                        <label>Email</label>
                                        {isEditing ? (
                                            <input
                                                type="email"
                                                name="email"
                                                value={profileData.email}
                                                onChange={handleInputChange}
                                            />
                                        ) : (
                                            <p>{profileData.email}</p>
                                        )}
                                    </div>
                                    <div className="info-item">
                                        <label>Phone</label>
                                        {isEditing ? (
                                            <input
                                                type="tel"
                                                name="phone"
                                                value={profileData.phone}
                                                onChange={handleInputChange}
                                            />
                                        ) : (
                                            <p>{profileData.phone}</p>
                                        )}
                                    </div>
                                </div>
                            </div>

                            {/* About Me */}
                            <div className="profile-section">
                                <h3>About Me</h3>
                                {isEditing ? (
                                    <textarea
                                        name="bio"
                                        value={profileData.bio}
                                        onChange={handleInputChange}
                                        rows="4"
                                    />
                                ) : (
                                    <p>{profileData.bio}</p>
                                )}
                            </div>

                            {/* Interests */}
                            <div className="profile-section">
                                <h3>Interests</h3>
                                <div className="interests-list">
                                    {profileData.interests.map((interest, index) => (
                                        <span key={index} className="interest-tag">
                                            {interest}
                                        </span>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Right Column */}
                        <div className="profile-right-column">
                            {/* Achievements */}
                            <div className="profile-section">
                                <h3>Achievements</h3>
                                <ul className="achievements-list">
                                    {profileData.achievements.map((achievement, index) => (
                                        <li key={index}>{achievement}</li>
                                    ))}
                                </ul>
                            </div>

                            {/* Recent Activity */}
                            <div className="profile-section">
                                <h3>Recent Activity</h3>
                                <div className="activity-list">
                                    {profileData.recentActivity.map((activity, index) => (
                                        <div key={index} className="activity-item">
                                            <div className="activity-icon">{activity.icon}</div>
                                            <div className="activity-content">
                                                <h4>{activity.title}</h4>
                                                <p>{activity.description}</p>
                                            </div>
                                            <div className="activity-date">{activity.date}</div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>

                    {isEditing && (
                        <div className="profile-actions">
                            <button className="save-btn" onClick={handleSave}>
                                Save Changes
                            </button>
                            <button className="cancel-btn" onClick={handleCancel}>
                                Cancel
                            </button>
                        </div>
                    )}
                </div>
            </main>

            {/* Footer */}
            <footer className="footer">
                <p>&copy; 2024 Campus Connect. All rights reserved.</p>
            </footer>

            {/* Overlay */}
            {isSidebarOpen && (
                <div className="overlay" onClick={toggleSidebar}></div>
            )}
        </div>
    );
};

export default Profile; 