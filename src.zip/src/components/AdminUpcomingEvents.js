import React, { useState } from 'react';
import AdminSidebar from './AdminSidebar';
import './AdminUpcomingEvents.css';

const AdminUpcomingEvents = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(false);
    // Sample data - replace with actual data from backend
    const [events, setEvents] = useState([
        {
            id: 1,
            title: 'Technical Workshop',
            date: '2024-03-15',
            time: '10:00 AM',
            type: 'workshop',
            location: 'Room 101',
            capacity: 50,
            registered: 35,
            status: 'upcoming',
            description: 'Advanced programming techniques workshop'
        },
        {
            id: 2,
            title: 'Coding Competition',
            date: '2024-03-15',
            time: '2:00 PM',
            type: 'competition',
            location: 'Auditorium',
            capacity: 100,
            registered: 75,
            status: 'upcoming',
            description: 'Annual coding competition for students'
        },
        {
            id: 3,
            title: 'AI Seminar',
            date: '2024-03-18',
            time: '11:00 AM',
            type: 'seminar',
            location: 'Conference Hall',
            capacity: 200,
            registered: 150,
            status: 'upcoming',
            description: 'Introduction to Artificial Intelligence'
        }
    ]);

    const [showAddModal, setShowAddModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [selectedEvent, setSelectedEvent] = useState(null);
    const [newEvent, setNewEvent] = useState({
        title: '',
        date: '',
        time: '',
        type: '',
        location: '',
        capacity: '',
        description: ''
    });

    const handleAddEvent = () => {
        // Add event logic here
        setShowAddModal(false);
        setNewEvent({
            title: '',
            date: '',
            time: '',
            type: '',
            location: '',
            capacity: '',
            description: ''
        });
    };

    const handleEditEvent = (event) => {
        setSelectedEvent(event);
        setShowEditModal(true);
    };

    const handleDeleteEvent = (eventId) => {
        // Delete event logic here
        setEvents(events.filter(event => event.id !== eventId));
    };

    const handleStatusChange = (eventId, newStatus) => {
        // Update status logic here
        setEvents(events.map(event => 
            event.id === eventId ? { ...event, status: newStatus } : event
        ));
    };

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    return (
        <div className="admin-upcoming-events">
            {/* Header */}
            <header className="admin-header">
                <div className="header-left">
                    <button className="menu-button" onClick={toggleSidebar}>☰</button>
                    <h1>Admin Panel</h1>
                </div>
            </header>

            {/* Admin Sidebar */}
            <AdminSidebar isOpen={isSidebarOpen} onClose={toggleSidebar} />

            {/* Main Content */}
            <main className="admin-main-content">
                <div className="admin-events-header">
                    <h2>Manage Upcoming Events</h2>
                    <button className="add-event-btn" onClick={() => setShowAddModal(true)}>
                        Add New Event
                    </button>
                </div>

                <div className="events-grid">
                    {events.map(event => (
                        <div key={event.id} className="admin-event-card">
                            <div className="event-header">
                                <h3>{event.title}</h3>
                                <div className="event-actions">
                                    <button 
                                        className="edit-btn"
                                        onClick={() => handleEditEvent(event)}
                                    >
                                        Edit
                                    </button>
                                    <button 
                                        className="delete-btn"
                                        onClick={() => handleDeleteEvent(event.id)}
                                    >
                                        Delete
                                    </button>
                                </div>
                            </div>
                            <div className="event-details">
                                <p><strong>Date:</strong> {event.date}</p>
                                <p><strong>Time:</strong> {event.time}</p>
                                <p><strong>Location:</strong> {event.location}</p>
                                <p><strong>Type:</strong> {event.type}</p>
                                <p><strong>Capacity:</strong> {event.registered}/{event.capacity}</p>
                                <p><strong>Status:</strong> 
                                    <select 
                                        value={event.status}
                                        onChange={(e) => handleStatusChange(event.id, e.target.value)}
                                    >
                                        <option value="upcoming">Upcoming</option>
                                        <option value="ongoing">Ongoing</option>
                                        <option value="completed">Completed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                </p>
                                <p><strong>Description:</strong> {event.description}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </main>

            {/* Overlay */}
            {isSidebarOpen && (
                <div className="overlay" onClick={toggleSidebar}></div>
            )}

            {/* Existing modals */}
            {showAddModal && (
                <div className="modal">
                    <div className="modal-content">
                        <h3>Add New Event</h3>
                        <form onSubmit={(e) => {
                            e.preventDefault();
                            handleAddEvent();
                        }}>
                            <div className="form-group">
                                <label>Title</label>
                                <input
                                    type="text"
                                    value={newEvent.title}
                                    onChange={(e) => setNewEvent({...newEvent, title: e.target.value})}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Date</label>
                                <input
                                    type="date"
                                    value={newEvent.date}
                                    onChange={(e) => setNewEvent({...newEvent, date: e.target.value})}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Time</label>
                                <input
                                    type="time"
                                    value={newEvent.time}
                                    onChange={(e) => setNewEvent({...newEvent, time: e.target.value})}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Type</label>
                                <select
                                    value={newEvent.type}
                                    onChange={(e) => setNewEvent({...newEvent, type: e.target.value})}
                                    required
                                >
                                    <option value="">Select Type</option>
                                    <option value="workshop">Workshop</option>
                                    <option value="seminar">Seminar</option>
                                    <option value="competition">Competition</option>
                                    <option value="fair">Fair</option>
                                </select>
                            </div>
                            <div className="form-group">
                                <label>Location</label>
                                <input
                                    type="text"
                                    value={newEvent.location}
                                    onChange={(e) => setNewEvent({...newEvent, location: e.target.value})}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Capacity</label>
                                <input
                                    type="number"
                                    value={newEvent.capacity}
                                    onChange={(e) => setNewEvent({...newEvent, capacity: e.target.value})}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Description</label>
                                <textarea
                                    value={newEvent.description}
                                    onChange={(e) => setNewEvent({...newEvent, description: e.target.value})}
                                    required
                                />
                            </div>
                            <div className="modal-actions">
                                <button type="submit" className="submit-btn">Add Event</button>
                                <button type="button" className="cancel-btn" onClick={() => setShowAddModal(false)}>
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {showEditModal && selectedEvent && (
                <div className="modal">
                    <div className="modal-content">
                        <h3>Edit Event</h3>
                        <form onSubmit={(e) => {
                            e.preventDefault();
                            // Edit event logic here
                            setShowEditModal(false);
                        }}>
                            <div className="form-group">
                                <label>Title</label>
                                <input
                                    type="text"
                                    value={selectedEvent.title}
                                    onChange={(e) => setSelectedEvent({...selectedEvent, title: e.target.value})}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Date</label>
                                <input
                                    type="date"
                                    value={selectedEvent.date}
                                    onChange={(e) => setSelectedEvent({...selectedEvent, date: e.target.value})}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Time</label>
                                <input
                                    type="time"
                                    value={selectedEvent.time}
                                    onChange={(e) => setSelectedEvent({...selectedEvent, time: e.target.value})}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Type</label>
                                <select
                                    value={selectedEvent.type}
                                    onChange={(e) => setSelectedEvent({...selectedEvent, type: e.target.value})}
                                    required
                                >
                                    <option value="workshop">Workshop</option>
                                    <option value="seminar">Seminar</option>
                                    <option value="competition">Competition</option>
                                    <option value="fair">Fair</option>
                                </select>
                            </div>
                            <div className="form-group">
                                <label>Location</label>
                                <input
                                    type="text"
                                    value={selectedEvent.location}
                                    onChange={(e) => setSelectedEvent({...selectedEvent, location: e.target.value})}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Capacity</label>
                                <input
                                    type="number"
                                    value={selectedEvent.capacity}
                                    onChange={(e) => setSelectedEvent({...selectedEvent, capacity: e.target.value})}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Description</label>
                                <textarea
                                    value={selectedEvent.description}
                                    onChange={(e) => setSelectedEvent({...selectedEvent, description: e.target.value})}
                                    required
                                />
                            </div>
                            <div className="modal-actions">
                                <button type="submit" className="submit-btn">Save Changes</button>
                                <button type="button" className="cancel-btn" onClick={() => setShowEditModal(false)}>
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AdminUpcomingEvents; 