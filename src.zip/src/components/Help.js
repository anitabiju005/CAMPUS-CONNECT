import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainSidebar from './MainSidebar';
import './Help.css';

const Help = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(false);
    const [activeSection, setActiveSection] = useState('getting-started');
    const navigate = useNavigate();

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    const scrollToSection = (sectionId) => {
        setActiveSection(sectionId);
        const element = document.getElementById(sectionId);
        element.scrollIntoView({ behavior: 'smooth' });
    };

    return (
        <div className={`help-container ${isSidebarOpen ? 'sidebar-open' : ''}`}>
            {/* Header */}
            <header className="header">
                <button className="menu-button" onClick={toggleSidebar}>☰</button>
                <h1>Campus Connect</h1>
            </header>

            {/* Main Sidebar */}
            <MainSidebar isOpen={isSidebarOpen} onClose={toggleSidebar} />

            {/* Main Content */}
            <main className="main-content">
                <div className="content-wrapper">
                    <div className="help-sidebar">
                        <h3>Help Topics</h3>
                        <nav className="help-nav">
                            <ul>
                                <li>
                                    <a 
                                        href="#getting-started" 
                                        className={activeSection === 'getting-started' ? 'active' : ''}
                                        onClick={() => scrollToSection('getting-started')}
                                    >
                                        Getting Started
                                    </a>
                                </li>
                                <li>
                                    <a 
                                        href="#features" 
                                        className={activeSection === 'features' ? 'active' : ''}
                                        onClick={() => scrollToSection('features')}
                                    >
                                        Features Guide
                                    </a>
                                </li>
                                <li>
                                    <a 
                                        href="#faq" 
                                        className={activeSection === 'faq' ? 'active' : ''}
                                        onClick={() => scrollToSection('faq')}
                                    >
                                        FAQs
                                    </a>
                                </li>
                                <li>
                                    <a 
                                        href="#contact" 
                                        className={activeSection === 'contact' ? 'active' : ''}
                                        onClick={() => scrollToSection('contact')}
                                    >
                                        Contact Support
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>

                    <div className="help-content">
                        {/* Getting Started Section */}
                        <section id="getting-started" className="help-section">
                            <h2>Getting Started with Campus Connect</h2>
                            <div className="section-content">
                                <h3>Welcome to Campus Connect!</h3>
                                <p>Campus Connect is your one-stop platform for managing all your campus activities, events, and academic progress. Here's how to get started:</p>
                                
                                <div className="steps-container">
                                    <div className="step">
                                        <div className="step-number">1</div>
                                        <div className="step-content">
                                            <h4>Complete Your Profile</h4>
                                            <p>Go to your profile page and fill in your personal information, academic details, and preferences.</p>
                                        </div>
                                    </div>
                                    <div className="step">
                                        <div className="step-number">2</div>
                                        <div className="step-content">
                                            <h4>Explore the Dashboard</h4>
                                            <p>Visit your dashboard to see upcoming events, your activity points, and recent achievements.</p>
                                        </div>
                                    </div>
                                    <div className="step">
                                        <div className="step-number">3</div>
                                        <div className="step-content">
                                            <h4>Register for Events</h4>
                                            <p>Browse through available events and register for those that interest you.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        {/* Features Guide Section */}
                        <section id="features" className="help-section">
                            <h2>Features Guide</h2>
                            <div className="section-content">
                                <div className="feature-card">
                                    <h3>Dashboard</h3>
                                    <p>Your dashboard provides a comprehensive overview of your campus activities:</p>
                                    <ul>
                                        <li>View upcoming events and deadlines</li>
                                        <li>Track your activity points and credits</li>
                                        <li>Access your event calendar</li>
                                        <li>Monitor your progress</li>
                                    </ul>
                                </div>

                                <div className="feature-card">
                                    <h3>Event Management</h3>
                                    <p>Easily manage your participation in campus events:</p>
                                    <ul>
                                        <li>Register for events</li>
                                        <li>View event details and schedules</li>
                                        <li>Track your attendance</li>
                                        <li>Earn activity points</li>
                                    </ul>
                                </div>

                                <div className="feature-card">
                                    <h3>Profile Settings</h3>
                                    <p>Customize your profile and preferences:</p>
                                    <ul>
                                        <li>Update personal information</li>
                                        <li>Manage privacy settings</li>
                                        <li>Set notification preferences</li>
                                        <li>Choose your preferred language</li>
                                    </ul>
                                </div>
                            </div>
                        </section>

                        {/* FAQ Section */}
                        <section id="faq" className="help-section">
                            <h2>Frequently Asked Questions</h2>
                            <div className="section-content">
                                <div className="faq-item">
                                    <h3>How do I earn activity points?</h3>
                                    <p>Activity points are earned by participating in campus events. Each event has a specific point value that you'll receive upon completion.</p>
                                </div>

                                <div className="faq-item">
                                    <h3>Can I cancel my event registration?</h3>
                                    <p>Yes, you can cancel your registration up to 24 hours before the event starts through the event details page.</p>
                                </div>

                                <div className="faq-item">
                                    <h3>How do I update my profile information?</h3>
                                    <p>Go to your profile page and click the "Edit Profile" button to update your information.</p>
                                </div>

                                <div className="faq-item">
                                    <h3>What happens if I miss an event?</h3>
                                    <p>If you miss a registered event, you won't receive activity points. However, you can still participate in future events.</p>
                                </div>
                            </div>
                        </section>

                        {/* Contact Support Section */}
                        <section id="contact" className="help-section">
                            <h2>Contact Support</h2>
                            <div className="section-content">
                                <div className="contact-info">
                                    <h3>Need Help?</h3>
                                    <p>Our support team is here to assist you with any questions or concerns.</p>
                                    
                                    <div className="contact-methods">
                                        <div className="contact-method">
                                            <div className="contact-icon">📧</div>
                                            <h4>Email Support</h4>
                                            <p>support@campusconnect.com</p>
                                        </div>
                                        <div className="contact-method">
                                            <div className="contact-icon">📞</div>
                                            <h4>Phone Support</h4>
                                            <p>+1 (555) 123-4567</p>
                                        </div>
                                        <div className="contact-method">
                                            <div className="contact-icon">💬</div>
                                            <h4>Live Chat</h4>
                                            <p>Available 24/7</p>
                                        </div>
                                    </div>

                                    <div className="support-form">
                                        <h3>Send us a Message</h3>
                                        <form>
                                            <div className="form-group">
                                                <label htmlFor="name">Name</label>
                                                <input type="text" id="name" placeholder="Your name" />
                                            </div>
                                            <div className="form-group">
                                                <label htmlFor="email">Email</label>
                                                <input type="email" id="email" placeholder="Your email" />
                                            </div>
                                            <div className="form-group">
                                                <label htmlFor="subject">Subject</label>
                                                <input type="text" id="subject" placeholder="Message subject" />
                                            </div>
                                            <div className="form-group">
                                                <label htmlFor="message">Message</label>
                                                <textarea id="message" placeholder="Your message" rows="5"></textarea>
                                            </div>
                                            <button type="submit" className="submit-button">Send Message</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </main>

            {/* Footer */}
            <footer className="footer">
                <p>&copy; 2024 Campus Connect. All rights reserved.</p>
            </footer>

            {/* Overlay */}
            {isSidebarOpen && (
                <div className="overlay" onClick={toggleSidebar}></div>
            )}
        </div>
    );
};

export default Help; 