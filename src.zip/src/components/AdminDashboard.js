import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AdminUpcomingEvents from './AdminUpcomingEvents';
import AdminCompletedEvents from './AdminCompletedEvents';
import './AdminDashboard.css';

const AdminDashboard = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(false);
    const [activeTab, setActiveTab] = useState('upcoming');
    const navigate = useNavigate();

    // Mock data for dashboard
    const [stats] = useState({
        totalUsers: 150,
        activeEvents: 8,
        totalEvents: 25,
        pendingApprovals: 5
    });

    const [upcomingEvents] = useState([
        {
            id: 1,
            title: 'Technical Workshop',
            type: 'Workshop',
            date: '2024-03-15',
            time: '10:00 AM - 1:00 PM',
            venue: 'Room 301, Computer Science Building',
            participants: 45,
            activityPoints: 50,
            registrationFee: '₹500',
            registrationLink: 'https://campusconnect.com/events/tech-workshop',
            status: 'Active'
        },
        {
            id: 2,
            title: 'Hackathon 2024',
            type: 'Competition',
            date: '2024-03-20',
            time: '9:00 AM - 6:00 PM',
            venue: 'Innovation Hub, Main Campus',
            participants: 120,
            activityPoints: 100,
            registrationFee: '₹1000',
            registrationLink: 'https://campusconnect.com/events/hackathon-2024',
            status: 'Pending'
        },
        {
            id: 3,
            title: 'Career Fair',
            type: 'General',
            date: '2024-03-25',
            time: '11:00 AM - 4:00 PM',
            venue: 'University Auditorium',
            participants: 200,
            activityPoints: 75,
            registrationFee: 'Free',
            registrationLink: 'https://campusconnect.com/events/career-fair',
            status: 'Active'
        }
    ]);

    const [completedEvents] = useState([
        {
            id: 4,
            title: 'Web Development Bootcamp',
            type: 'Workshop',
            date: '2024-02-15',
            time: '10:00 AM - 1:00 PM',
            venue: 'Room 301, Computer Science Building',
            participants: 75,
            activityPoints: 50,
            registrationFee: '₹500',
            status: 'Completed',
            report: 'The workshop was well-received with high participant engagement. Topics covered included modern web development practices and frameworks.'
        },
        {
            id: 5,
            title: 'AI Competition 2024',
            type: 'Competition',
            date: '2024-02-20',
            time: '9:00 AM - 6:00 PM',
            venue: 'Innovation Hub, Main Campus',
            participants: 150,
            activityPoints: 100,
            registrationFee: '₹1000',
            status: 'Completed',
            winners: {
                first: 'Team Alpha - John Doe & Jane Smith',
                second: 'Team Beta - Mike Johnson & Sarah Wilson',
                third: 'Team Gamma - Alex Brown & Emma Davis'
            }
        },
        {
            id: 6,
            title: 'Networking Event',
            type: 'General',
            date: '2024-02-25',
            time: '11:00 AM - 4:00 PM',
            venue: 'University Auditorium',
            participants: 100,
            activityPoints: 75,
            registrationFee: 'Free',
            status: 'Completed',
            report: 'Successful networking event with industry professionals. Students had valuable interactions and made meaningful connections.'
        }
    ]);

    const [recentUsers] = useState([
        {
            id: 1,
            name: 'John Doe',
            email: 'john@example.com',
            department: 'Computer Science',
            joinDate: '2024-01-15'
        },
        {
            id: 2,
            name: 'Jane Smith',
            email: 'jane@example.com',
            department: 'Engineering',
            joinDate: '2024-02-01'
        },
        {
            id: 3,
            name: 'Mike Johnson',
            email: 'mike@example.com',
            department: 'Business',
            joinDate: '2024-02-15'
        }
    ]);

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    const handleNavigation = (path) => {
        if (path === '/admin-dashboard') {
            navigate(path);
        }
        setSidebarOpen(false);
    };

    const handleLogout = () => {
        localStorage.removeItem('isAdmin');
        navigate('/administrator');
    };

    const handleTabChange = (tab) => {
        setActiveTab(tab);
    };

    return (
        <div className={`admin-dashboard ${isSidebarOpen ? 'sidebar-open' : ''}`}>
            {/* Header */}
            <header className="admin-header">
                <button className="menu-button" onClick={toggleSidebar}>☰</button>
                <h1>Admin Dashboard</h1>
                <button className="logout-button" onClick={handleLogout}>Logout</button>
            </header>

            {/* Sidebar */}
            <div className={`admin-sidebar ${isSidebarOpen ? 'open' : ''}`}>
                <div className="sidebar-header">
                    <h2>Admin Menu</h2>
                    <button className="close-button" onClick={toggleSidebar}>×</button>
                </div>
                <nav className="sidebar-nav">
                    <ul>
                        <li><button onClick={() => handleNavigation('/admin-dashboard')}>Dashboard</button></li>
                        <li><button onClick={() => setActiveTab('upcoming')}>Upcoming Events</button></li>
                        <li><button onClick={() => setActiveTab('completed')}>Completed Events</button></li>
                        <li><button onClick={handleLogout}>Logout</button></li>
                    </ul>
                </nav>
            </div>

            {/* Main Content */}
            <main className="admin-main-content">
                <div className="admin-content-wrapper">
                    {/* Statistics Cards */}
                    <div className="admin-stats-container">
                        <div className="admin-stat-card">
                            <div className="stat-icon">👥</div>
                            <div className="stat-content">
                                <h3>Total Users</h3>
                                <p className="stat-number">{stats.totalUsers}</p>
                            </div>
                        </div>
                        <div className="admin-stat-card">
                            <div className="stat-icon">📅</div>
                            <div className="stat-content">
                                <h3>Active Events</h3>
                                <p className="stat-number">{stats.activeEvents}</p>
                            </div>
                        </div>
                        <div className="admin-stat-card">
                            <div className="stat-icon">🎯</div>
                            <div className="stat-content">
                                <h3>Total Events</h3>
                                <p className="stat-number">{stats.totalEvents}</p>
                            </div>
                        </div>
                        <div className="admin-stat-card">
                            <div className="stat-icon">⏳</div>
                            <div className="stat-content">
                                <h3>Pending Approvals</h3>
                                <p className="stat-number">{stats.pendingApprovals}</p>
                            </div>
                        </div>
                    </div>

                    {/* Events Tabs */}
                    <div className="admin-tabs">
                        <button 
                            className={`tab-button ${activeTab === 'upcoming' ? 'active' : ''}`}
                            onClick={() => handleTabChange('upcoming')}
                        >
                            Upcoming Events
                        </button>
                        <button 
                            className={`tab-button ${activeTab === 'completed' ? 'active' : ''}`}
                            onClick={() => handleTabChange('completed')}
                        >
                            Completed Events
                        </button>
                    </div>

                    {/* Tab Content */}
                    <div className="tab-content">
                        {activeTab === 'upcoming' ? <AdminUpcomingEvents /> : <AdminCompletedEvents />}
                    </div>

                    {/* Recent Users Table */}
                    <div className="admin-section">
                        <div className="section-header">
                            <h2>Recent Users</h2>
                            <button className="add-button">Add New User</button>
                        </div>
                        <div className="table-container">
                            <table className="admin-table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Department</th>
                                        <th>Join Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {recentUsers.map(user => (
                                        <tr key={user.id}>
                                            <td>{user.name}</td>
                                            <td>{user.email}</td>
                                            <td>{user.department}</td>
                                            <td>{user.joinDate}</td>
                                            <td>
                                                <button className="action-button edit">Edit</button>
                                                <button className="action-button delete">Delete</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>

            {/* Overlay */}
            {isSidebarOpen && (
                <div className="overlay" onClick={toggleSidebar}></div>
            )}
        </div>
    );
};

export default AdminDashboard; 