import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainSidebar from './MainSidebar';
import './RegisteredEvents.css';

const RegisteredEvents = () => {
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Mock data for registered events
  const registeredEvents = [
    {
      id: 1,
      title: "Web Development Workshop",
      date: "2025-03-28",
      time: "10:00 AM",
      venue: "Room 101",
      type: "Workshop",
      status: "Upcoming",
      activityPoints: 5
    },
    /*{
      id: 2,
      title: "Database Management Seminar",
      date: "2024-03-20",
      time: "2:00 PM",
      venue: "Auditorium",
      type: "Seminar",
      status: "Upcoming",
      activityPoints: 3
    },*/
    {
      id: 3,
      title: "Machine Learning Workshop",
      date: "2025-03-27",
      time: "11:00 AM",
      venue: "Lab 205",
      type: "Workshop",
      status: "Upcoming",
      activityPoints: 5
    },
    /*{
      id: 4,
      title: "Cloud Computing Seminar",
      date: "2024-03-30",
      time: "3:00 PM",
      venue: "Conference Hall",
      type: "Seminar",
      status: "Upcoming",
      activityPoints: 3
    }*/
  ];

  return (
    <div className="registered-events-container">
      <MainSidebar 
        isOpen={isSidebarOpen} 
        onClose={toggleSidebar}
      />
      
      <div className={`main-content ${isSidebarOpen ? 'shifted' : ''}`}>
        <header className="header">
          <button className="menu-button" onClick={toggleSidebar}>
            ☰
          </button>
          <h1>Registered Events</h1>
        </header>

        <main className="events-grid">
          {registeredEvents.map(event => (
            <div key={event.id} className="event-card">
              <h3>{event.title}</h3>
              <div className="event-details">
                <div className="details-row">
                  <p><strong>Date:</strong> {event.date}</p>
                  <p><strong>Time:</strong> {event.time}</p>
                </div>
                <div className="details-row">
                  <p><strong>Venue:</strong> {event.venue}</p>
                  <p><strong>Type:</strong> {event.type}</p>
                </div>
                <div className="details-row">
                  <p><strong>Status:</strong> {event.status}</p>
                  <p><strong>Activity Points:</strong> {event.activityPoints}</p>
                </div>
              </div>
              {/* <a href={`/registered-events/${event.id}`} className="view-details-button">
                View Details
              </a> */}
            </div>
          ))}
        </main>
      </div>

      {isSidebarOpen && (
        <div className="overlay" onClick={toggleSidebar}></div>
      )}
    </div>
  );
};

export default RegisteredEvents; 