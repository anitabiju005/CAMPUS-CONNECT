import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Administrator.css';

const Administrator = () => {
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        // For demo purposes, using a simple password check
        if (password === 'admin123') {
            localStorage.setItem('isAdmin', 'true');
            navigate('/admin-dashboard');
        } else {
            setError('Invalid administrator password');
        }
    };

    return (
        <div className="admin-container">
            <div className="admin-box">
                <h2>Administrator Access</h2>
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="password">Administrator Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Enter administrator password"
                            required
                        />
                    </div>
                    {error && <div className="error-message">{error}</div>}
                    <button type="submit" className="admin-login-button">
                        Login as Administrator
                    </button>
                </form>
            </div>
        </div>
    );
};

export default Administrator; 