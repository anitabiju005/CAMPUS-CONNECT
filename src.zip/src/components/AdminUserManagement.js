import React, { useState } from 'react';
import AdminSidebar from './AdminSidebar';
import './AdminUserManagement.css';

const AdminUserManagement = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(false);
    const [users, setUsers] = useState([
        {
            id: 1,
            name: 'John Doe',
            email: 'john@example.com',
            role: 'student',
            status: 'active'
        },
        {
            id: 2,
            name: 'Jane Smith',
            email: 'jane@example.com',
            role: 'faculty',
            status: 'active'
        }
    ]);

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    return (
        <div className="admin-user-management">
            {/* Header */}
            <header className="admin-header">
                <div className="header-left">
                    <button className="menu-button" onClick={toggleSidebar}>☰</button>
                    <h1>Admin Panel</h1>
                </div>
            </header>

            {/* Admin Sidebar */}
            <AdminSidebar isOpen={isSidebarOpen} onClose={toggleSidebar} />

            {/* Main Content */}
            <main className="admin-main-content">
                <div className="admin-users-header">
                    <h2>User Management</h2>
                    <button className="add-user-btn">
                        Add New User
                    </button>
                </div>

                <div className="users-table-container">
                    <table className="users-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.map(user => (
                                <tr key={user.id}>
                                    <td>{user.name}</td>
                                    <td>{user.email}</td>
                                    <td>{user.role}</td>
                                    <td>{user.status}</td>
                                    <td>
                                        <button className="edit-btn">Edit</button>
                                        <button className="delete-btn">Delete</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </main>

            {/* Overlay */}
            {isSidebarOpen && (
                <div className="overlay" onClick={toggleSidebar}></div>
            )}
        </div>
    );
};

export default AdminUserManagement; 