import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';

// Import components
import Home from './components/Home';
import Login from './components/Login';
import Profile from './components/Profile';
import Settings from './components/Settings';
import Help from './components/Help';
import Administrator from './components/Administrator';
import AdminLogin from './components/AdminLogin';
import AdminDashboard from './components/AdminDashboard';
import AdminUpcomingEvents from './components/AdminUpcomingEvents';
import AdminCompletedEvents from './components/AdminCompletedEvents';
import AdminUserManagement from './components/AdminUserManagement';
import AdminSettings from './components/AdminSettings';
import UpcomingEvents from './components/UpcomingEvents';
import RegisteredEvents from './components/RegisteredEvents';
import UpcomingEventDetails from './components/UpcomingEventDetails';
import RegisteredEventDetails from './components/RegisteredEventDetails';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Public Routes */}
          <Route path="/home" element={<Home />} />
          <Route path="/" element={<Login />} />
          
          {/* User Routes */}
          <Route path="/profile" element={<Profile />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/help" element={<Help />} />
          <Route path="/upcoming-events" element={<UpcomingEvents />} />
          <Route path="/upcoming-events/:id" element={<UpcomingEventDetails />} />
          <Route path="/registered-events" element={<RegisteredEvents />} />
          <Route path="/registered-events/:id" element={<RegisteredEventDetails />} />
          
          {/* Admin Routes */}
          <Route path="/admin" element={<Administrator />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/upcoming-events" element={<AdminUpcomingEvents />} />
          <Route path="/admin/completed-events" element={<AdminCompletedEvents />} />
          <Route path="/admin/user-management" element={<AdminUserManagement />} />
          <Route path="/admin/settings" element={<AdminSettings />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

